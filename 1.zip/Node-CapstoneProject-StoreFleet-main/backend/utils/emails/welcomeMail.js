// Import the necessary modules here
import nodemailer  from "nodemailer";
import dotenv from "dotenv"
import path from "path"
import { fileURLToPath } from 'url';
import { dirname } from 'path';
const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);
// const configPath = path.resolve("backend", "config", "uat.env");
const configPath = path.resolve(__dirname, "config", "uat.env");

dotenv.config({ path: configPath });
const transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: process.env.STORFLEET_SMPT_MAIL,
    pass: process.env.STORFLEET_SMPT_MAIL_PASSWORD,
  },
});
export const sendWelcomeEmail = async (user) => {
  // Write your code here
   // Compose the email
   const mailOptions = {
    from: process.env.STORFLEET_SMPT_MAIL,
    to: user.email,
    subject: 'Welcome to Our Service',
    html: `
    <html>
    <body style = "text-align:center">
      <img  src = "https://files.codingninjas.in/logo1-32230.png?_ga=2.234138718.1384884345.1703779595-1054841414.1683732071">
    </body>
    <p>Hello ${user.username},</p><p>Welcome to our service!</p>`,
  };

  // Send the email
  try {
    const info = await transporter.sendMail(mailOptions);
    console.log('Email sent: ' + info.response);
  } catch (error) {
    console.error('Error sending email:', error);
  }
};
